---
name: orchstate-project-scaffold
description: >
  Generate a complete, ready-to-code project folder structure for OrchState development
  including the full .claude/ directory with agents, hooks, rules, skills, and settings.
  Use this skill whenever the user asks to scaffold a project, create a project folder,
  generate a project structure, set up a new repo, prepare a developer handoff folder, or
  create a starter project for Claude Code. Also trigger when the user says create a project
  package for the developers, set up the folder structure for a new product, prepare
  everything the AO team needs to start coding, bootstrap a project, or any request that
  involves producing a downloadable folder with CLAUDE.md files, Wave markdown files, and
  the correct directory hierarchy for agent-orchestrated development.
---

# OrchState Project Scaffold Generator

## Purpose

Generate a complete, downloadable project folder that a developer can open in Claude Code
and immediately start executing Waves. This is the bridge between Product Design and
Engineering: Product Designers produce Wave-Ready Packages, this skill assembles them into
a structured project directory with all agent configuration files, hook scripts, rule files,
skill definitions, API contract stubs, and documentation wired together.

The output is a zip file containing a fully configured project skeleton. No setup, no
copy-pasting, no guesswork for the AO team.

---

## When to Use This Skill

Use this skill when the user needs a **physical folder structure**, not just document
content. If they only need a single CLAUDE.md file, use `orchstate-agent-config`. If they
only need a single Wave-Ready Package document, use `orchstate-wave-ready-package`. Use
this skill when they need the whole thing assembled into a project directory.

---

## Intake: Gather Project Details

Before generating anything, collect the following. Ask all questions in a single prompt.

### Required Information

1. **Project name** — Used for the root folder name, CLAUDE.md headers, and zip filename
2. **Project description** — 2-3 sentence business context
3. **Stack selection** — One of:
   - **Organization default** (Flutter/Riverpod + Hono/Bun + Drizzle/PostgreSQL + Alibaba
     Cloud KSA)
   - **Custom stack** (triggers the interview from `orchstate-agent-config` skill's
     `references/stack-custom.md`)
4. **Wave-Ready Packages** — Ask whether the user:
   - a) Will paste WRP content into this conversation for inclusion
   - b) Has existing WRP documents to upload
   - c) Wants empty Wave template files as placeholders
   - d) Wants to generate WRPs now using the `orchstate-wave-ready-package` skill flow
5. **Authentication method** — What auth system (Nafath, Auth0, Firebase Auth, Supabase
   Auth, custom JWT, none yet)
6. **Bilingual support** — Does the product require Arabic/RTL support?
7. **MCP servers** — Any known MCP servers the team will use (or "none yet")

### Optional Information (ask only if relevant)
- **Existing API specs** — Does the user have OpenAPI files to include?
- **Design system** — Is there an existing design system or component library?
- **Deployment target** — Specific environment details beyond what the stack implies

---

## Output Structure

Generate the following directory tree. Read `references/structure.md` for the complete
specification of what goes in each file.

```
[project-name]/
├── CLAUDE.md                          # Lean master agent config (~100 lines)
├── CLAUDE.local.md                    # Personal overrides (gitignored, empty template)
├── MANUAL_TASKS.md                    # Manual Tasks Tracker (version controlled)
├── README.md                          # Project overview for humans
├── .env.example                       # Environment variable template
├── .gitignore                         # Includes .claude/settings.local.json,
│                                      # CLAUDE.local.md, .claude/backups/
├── .claude/                           # Claude Code configuration (full OrchState structure)
│   ├── settings.json                  # Permissions, defaults, and hook configuration
│   │                                  # (correct nested format with type field)
│   ├── settings.local.json            # Personal overrides (gitignored, empty template)
│   ├── agents/                        # Subagent definitions (auto-invoked by Claude Code)
│   │   ├── frontend-agent.md          # model: sonnet, isolation: worktree, effort: high
│   │   ├── backend-agent.md           # model: sonnet, isolation: worktree, effort: high
│   │   ├── database-agent.md          # model: sonnet, isolation: worktree, effort: high
│   │   ├── test-agent.md              # model: sonnet, isolation: worktree, effort: medium
│   │   └── infra-agent.md             # model: sonnet, isolation: worktree, effort: high
│   ├── hooks/                         # Deterministic quality enforcement
│   │   ├── pre-commit.sh              # PreToolUse: lint + format + tests (blocking)
│   │   ├── lint-on-save.sh            # PostToolUse: lint on file (blocking)
│   │   ├── session-start.sh           # SessionStart: inject context (blocking)
│   │   └── pre-compact.sh             # PreCompact: backup before compaction (async)
│   │   # SubagentStop: prompt-type configured in settings.json, no script file
│   ├── rules/                         # Domain-specific conventions (auto-loaded)
│   │   ├── frontend.md
│   │   ├── backend.md
│   │   ├── database.md
│   │   ├── api-contracts.md
│   │   ├── testing.md
│   │   ├── infrastructure.md
│   │   └── manual-tasks.md            # Manual Tasks Tracker convention (cross-cutting)
│   ├── backups/                       # Pre-compact backups (gitignored)
│   │   └── .gitkeep
│   └── skills/                        # On-demand workflow definitions
│       │
│       │  ## AO (Agent Orchestrator) Skills
│       ├── implement/SKILL.md         # WRP implementation with CQG + WEC
│       ├── gate/SKILL.md              # Quality Gate self-assessment (shared all roles)
│       ├── validate/SKILL.md          # Check against acceptance criteria
│       ├── fix/SKILL.md               # Bug fix + regression test
│       ├── test/SKILL.md              # Comprehensive test suite generation
│       ├── refactor/SKILL.md          # Refactor preserving functionality
│       ├── review/SKILL.md            # QG checklist per criterion
│       ├── api/SKILL.md               # API endpoint per contract spec
│       ├── memory/SKILL.md            # CLAUDE.md / rules update (shared all roles)
│       ├── parallel/SKILL.md          # Parallel subagent execution
│       │
│       │  ## QO (Quality Orchestrator) Skills
│       ├── testcases/SKILL.md         # TEC + test generation step by step
│       ├── automate/SKILL.md          # Test automation scripts
│       ├── coverage/SKILL.md          # Coverage gap analysis
│       ├── decision/SKILL.md          # QG approve/reject decision structure
│       │
│       │  ## PE (Platform Engineer) Skills
│       ├── pipeline/SKILL.md          # CI/CD pipeline (<15 min SLA)
│       ├── provision/SKILL.md         # Terraform module generation
│       ├── mcp-config/SKILL.md        # MCP server configuration
│       ├── monitor/SKILL.md           # Monitoring + alerting config
│       ├── rollback/SKILL.md          # Rollback procedure generation
│       └── incident/SKILL.md          # Incident response workflow
├── mobile/                            # Frontend application
│   ├── CLAUDE.md                      # Frontend Agent context (lean, references rules)
│   └── .gitkeep
├── backend/                           # Backend API
│   ├── CLAUDE.md                      # Backend Agent context (lean, references rules)
│   └── .gitkeep
├── database/                          # Database layer
│   ├── CLAUDE.md                      # Database Agent context (lean, references rules)
│   └── migrations/
│       └── .gitkeep
├── docs/
│   ├── architecture/
│   │   └── decisions.md               # ADR log (empty template)
│   ├── api-contracts/
│   │   └── openapi.yaml               # Stub or populated from WRPs
│   ├── wave-packages/
│   │   ├── README.md                  # Index of all Wave-Ready Packages
│   │   ├── wave-001-[feature].md
│   │   └── ...
│   └── agent-prompts/
│       └── README.md                  # Reusable prompt templates
├── tests/
│   ├── CLAUDE.md                      # Test Agent context (lean, references rules)
│   └── .gitkeep
├── infra/
│   ├── CLAUDE.md                      # Infrastructure Agent context (lean, refs rules)
│   └── .gitkeep
└── .mcp/
    └── mcp-config.json                # MCP server configuration
```

### Directory Naming

If the stack uses a web frontend instead of mobile (React, Next.js, Vue, Angular), rename
`mobile/` to `frontend/`. If both exist, include both `mobile/` and `web/`.

---

## File Generation Rules

### CLAUDE.md Files

Generate using the same logic as `orchstate-agent-config`:

- **Master CLAUDE.md at root**: Lean (~100 lines) with project overview, architecture,
  shared code standards, agent boundary table, `.claude/` directory references, Manual
  Tasks Tracker instruction, Wave lifecycle summary, Quality Gate criteria reference
- **Agent-specific CLAUDE.md files**: Lean (~50 lines each) with role description, key
  constraints, Manual Tasks reference, and reference to `.claude/rules/[domain].md`
- **All OrchState methodology sections included**: Clarifying Questions Gate, step-and-
  verify, memory update protocol, Manual Tasks Tracker convention
- **Critical**: CLAUDE.md files reference `.claude/rules/` for detailed conventions rather
  than embedding them

### .claude/settings.json

Generate with the **correct nested hook format**:

```json
{
  "$schema": "https://json.schemastore.org/claude-code-settings.json",
  "permissions": {
    "allow": [
      "Bash([PACKAGE_MANAGER] run *)",
      "Bash(git status)",
      "Bash(git diff *)",
      "Bash(git log *)",
      "Bash([LINTER] *)",
      "Bash([TEST_RUNNER] *)"
    ]
  },
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "git commit",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/pre-commit.sh"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/lint-on-save.sh $FILE"
          }
        ]
      }
    ],
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/session-start.sh"
          }
        ]
      }
    ],
    "PreCompact": [
      {
        "matcher": "auto",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/pre-compact.sh",
            "async": true
          }
        ]
      }
    ],
    "SubagentStop": [
      {
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Evaluate whether the subagent completed its OrchState Wave task correctly. Check the subagent's last message for: (1) all acceptance criteria from the Wave-Ready Package addressed, (2) no TODO or placeholder comments remaining in generated code, (3) tests written alongside implementation, (4) no hallucinated functionality beyond the spec, (5) any manual tasks encountered during execution were logged to MANUAL_TASKS.md. If the output satisfies all five criteria, respond ok. If issues exist, respond with the specific gaps that need to be fixed before the Wave proceeds to Quality Gate.",
            "timeout": 30
          }
        ]
      }
    ]
  }
}
```

**Critical format rules:**
- Every event entry must have a `hooks` array (not a `command` field directly)
- Every hook item must have `"type"` — one of `"command"`, `"prompt"`, or `"agent"`
- SessionStart and SubagentStop do not require a `matcher`
- `"async": true` on PreCompact runs the backup without blocking Claude

### .claude/agents/*.md (Subagent Definitions)

Generate one subagent definition per agent role with the **complete frontmatter**:

```yaml
---
name: backend-agent
description: >
  Use proactively when implementing API endpoints, business logic, server-side validation,
  or service layer code. Auto-delegates for any task that involves creating or modifying
  backend routes, controllers, services, or middleware. Do not use for frontend, database
  schema changes, or infrastructure.
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
isolation: worktree
effort: high
color: blue
skills:
  - gate
  - validate
---

You are the Backend Agent in an OrchState project...
```

**Mandatory frontmatter fields:**

| Field | Value |
|-------|-------|
| `name` | Kebab-case, matches filename |
| `description` | Action-oriented trigger language for auto-delegation |
| `tools` | Role-appropriate tool list |
| `model` | `sonnet` for implementation; `haiku` only for trivial checks |
| `isolation` | Always `worktree` |
| `effort` | `high` for implementation; `medium` for review/test |
| `color` | Distinct color per agent (frontend: green, backend: blue, db: yellow,
  test: magenta, infra: cyan) |
| `skills` | List OrchState skills to preload at startup |

**System prompt body must reference** `.claude/rules/[domain].md` for detailed conventions
rather than embedding full convention lists inline. This prevents drift between the rule
file and the subagent prompt.

### .claude/hooks/*.sh (Hook Scripts)

Generate **four hook scripts** populated with the correct commands for the selected stack.
The SubagentStop hook is a `prompt` type in settings.json — no script file needed.

**pre-commit.sh:**
```bash
#!/bin/bash
set -e

# OrchState Pre-Commit Quality Gate
# Event: PreToolUse (matcher: git commit)
# Time budget: <10 seconds | Exit 0 = pass, non-zero = block

[FORMATTER] --check .
[LINTER] .
[TEST_RUNNER] --run --reporter=dot
```

**lint-on-save.sh:**
```bash
#!/bin/bash
set -e

# OrchState Lint-on-Save
# Event: PostToolUse (matcher: Edit|Write)
# Time budget: <3 seconds | Exit 0 = pass, non-zero = block

FILE="$1"
if [ -n "$FILE" ]; then
  [LINTER] "$FILE"
fi
```

**session-start.sh:**
```bash
#!/bin/bash

# OrchState Session Start Context Injection
# Event: SessionStart (no matcher needed)
# Output to stdout is automatically injected into Claude's context

echo "=== OrchState Session Context ==="
echo "Date: $(date)"
echo ""
echo "Git status:"
git status --short 2>/dev/null || echo "(not a git repo)"
echo ""
echo "Current branch:"
git branch --show-current 2>/dev/null || echo "(unknown)"
echo ""
echo "Active Wave packages:"
ls docs/wave-packages/*.md 2>/dev/null | grep -v README | head -5 || echo "(none found)"
echo ""
echo "Recent CLAUDE.md learnings:"
grep "^- 20" CLAUDE.md 2>/dev/null | tail -5 || echo "(none)"
echo ""

# === Manual Tasks Tracker ===
if [ -f "MANUAL_TASKS.md" ]; then
  PENDING_COUNT=$(grep -c '^\- \[ \]' MANUAL_TASKS.md 2>/dev/null || echo "0")
  if [ "$PENDING_COUNT" -gt 0 ]; then
    echo "⚠ PENDING MANUAL TASKS: $PENDING_COUNT item(s) require human action"
    echo "---"
    grep '^\- \[ \]' MANUAL_TASKS.md 2>/dev/null | head -10
    echo "---"
    echo "Review full list: MANUAL_TASKS.md"
    echo "These tasks cannot be automated. Complete them before they block dependent work."
  else
    echo "Manual tasks: All completed ✓"
  fi
else
  echo "Manual tasks: No tracker file (MANUAL_TASKS.md will be created when needed)"
fi
```

**pre-compact.sh:**
```bash
#!/bin/bash

# OrchState Pre-Compact Backup
# Event: PreCompact (matcher: auto) | async: true — does not block Claude
# Backs up CLAUDE.md, rules, and MANUAL_TASKS.md before autocompaction

BACKUP_DIR=".claude/backups"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

mkdir -p "$BACKUP_DIR"

cp CLAUDE.md "$BACKUP_DIR/CLAUDE-$TIMESTAMP.md" 2>/dev/null || true

if [ -d ".claude/rules" ]; then
  tar -czf "$BACKUP_DIR/rules-$TIMESTAMP.tar.gz" .claude/rules/ 2>/dev/null || true
fi

# Backup manual tasks tracker (prevent compaction from losing task awareness)
if [ -f "MANUAL_TASKS.md" ]; then
  cp MANUAL_TASKS.md "$BACKUP_DIR/MANUAL_TASKS-$TIMESTAMP.md" 2>/dev/null || true
fi

echo "OrchState: Compaction backup saved → $BACKUP_DIR/CLAUDE-$TIMESTAMP.md"
echo "To restore context after compaction: read $BACKUP_DIR/CLAUDE-$TIMESTAMP.md"
```

Ensure all scripts are marked executable (`chmod +x .claude/hooks/*.sh`).

### .claude/rules/*.md (Rule Files)

Generate one file per applicable domain, populated from the selected stack profile.

Each rule file follows the template:
```markdown
# [Domain] Conventions

## Naming
[Domain-specific naming rules]

## Patterns
[Specific patterns with brief code examples]

## Testing
[Domain-specific testing requirements]

## DO NOT
[Domain-specific anti-patterns]
```

### .claude/skills/*/SKILL.md (Skill Definitions) — CRITICAL

**Every skill directory MUST contain a SKILL.md file with complete workflow content.**
A skill file with only YAML frontmatter and no workflow body is broken: Claude Code will
see the skill name in the `/` menu but will have no instructions to execute when the
developer invokes it. This is equivalent to shipping a function with a signature but no
implementation.

Generate each SKILL.md using the **full content templates** defined in
`references/structure.md` under the "Skills Content Templates" section. Each template
includes:

1. **YAML frontmatter** — name, description, user-invocable, argument-hint
2. **Purpose** — what the skill does and when to use it
3. **Workflow** — numbered step-by-step execution sequence
4. **Output format** — exact structure of the skill's deliverable
5. **Quality criteria** — what "done" looks like for this skill

**The 20 skills to generate:**

| # | Directory | Role | Invocation |
|---|-----------|------|------------|
| 1 | implement/ | AO | /implement [feature] |
| 2 | gate/ | Shared | /gate |
| 3 | validate/ | AO | /validate |
| 4 | fix/ | AO | /fix [description] |
| 5 | test/ | AO | /test [file/feature] |
| 6 | refactor/ | AO | /refactor [file] |
| 7 | review/ | AO | /review [code] |
| 8 | api/ | AO | /api [endpoint] |
| 9 | memory/ | Shared | /memory [learning] |
| 10 | parallel/ | AO | /parallel [role] |
| 11 | testcases/ | QO | /testcases [feature] |
| 12 | automate/ | QO | /automate [feature] |
| 13 | coverage/ | QO | /coverage [module] |
| 14 | decision/ | QO | /decision [wave summary] |
| 15 | pipeline/ | PE | /pipeline [project] |
| 16 | provision/ | PE | /provision [resource] |
| 17 | mcp-config/ | PE | /mcp [server] |
| 18 | monitor/ | PE | /monitor [service] |
| 19 | rollback/ | PE | /rollback [service] |
| 20 | incident/ | PE | /incident [description] |

**Do NOT generate skill files with only frontmatter.** Every skill must have a complete
workflow body. If a skill file is under 20 lines, it is almost certainly incomplete.

### Wave Package Files

For each Wave-Ready Package provided or generated:
- Create `wave-NNN-[feature-slug].md` in `docs/wave-packages/`
- NNN is zero-padded (001, 002...)
- Update `docs/wave-packages/README.md` index

### .gitignore

Include standard entries plus:
```
CLAUDE.local.md
.claude/settings.local.json
.claude/worktrees/
.claude/backups/
```

---

## Assembly and Delivery

After generating all files:

1. Create the complete directory tree in the working directory
2. Write every file with its full content (no empty files except .gitkeep placeholders)
3. Mark hook scripts as executable (`chmod +x .claude/hooks/*.sh`)
4. Zip the entire project folder
5. Present the zip file to the user for download

### Pre-Delivery Checklist

**CLAUDE.md Files:**
- [ ] Master CLAUDE.md is under ~100 lines (~2,500 tokens)
- [ ] Master CLAUDE.md references `.claude/` directory structure including all 5 hooks
- [ ] Every subdirectory CLAUDE.md has role-specific content (not duplicates)
- [ ] Detailed conventions delegated to `.claude/rules/`, not embedded

**Subagents:**
- [ ] `.claude/agents/` contains one definition per applicable role
- [ ] Every subagent includes `isolation: worktree` in frontmatter
- [ ] Every subagent includes `effort` and `color` fields
- [ ] Every subagent includes `skills` field with relevant preloaded skills
- [ ] Subagent descriptions use action-oriented trigger language ("Use proactively when...")
- [ ] Subagent system prompts reference `.claude/rules/` files, not embedding conventions
- [ ] Subagent system prompts include Manual Tasks Tracker instruction

**Hooks (all 5 must be present):**
- [ ] `pre-commit.sh` exists with correct linter/formatter/test commands
- [ ] `lint-on-save.sh` exists
- [ ] `session-start.sh` exists, outputs context, and displays pending manual tasks
- [ ] `pre-compact.sh` exists and backs up CLAUDE.md, rules, and MANUAL_TASKS.md
- [ ] All scripts marked executable
- [ ] All hook scripts complete in under 10 seconds

**settings.json:**
- [ ] Uses correct nested format: event → array of groups → `hooks` array with `type` field
- [ ] PreToolUse registered for `git commit` → pre-commit.sh
- [ ] PostToolUse registered for `Edit|Write` → lint-on-save.sh
- [ ] SessionStart registered (no matcher) → session-start.sh
- [ ] PreCompact registered for `auto` matcher → pre-compact.sh with `"async": true`
- [ ] SubagentStop registered with `"type": "prompt"` and 5-criteria evaluation (not a command)
- [ ] Permission allows list populated for package manager, linter, test runner

**Rules:**
- [ ] `.claude/rules/` contains one file per applicable domain plus `manual-tasks.md`
- [ ] Rule files populated with stack-specific conventions
- [ ] `manual-tasks.md` rule file includes format, logging rules, .env.example sync, and categories
- [ ] No overlap between rule files

**Skills (CRITICAL — verify content, not just existence):**
- [ ] `.claude/skills/` contains all 20 skill directories (10 AO + 4 QO + 6 PE)
- [ ] Each SKILL.md has proper YAML frontmatter with `user-invocable: true`
- [ ] Each SKILL.md has a complete workflow body (purpose, steps, output format, criteria)
- [ ] No SKILL.md is under 20 lines (indicates missing workflow content)
- [ ] Skill workflows reference OrchState constructs (CQG, WEC, TEC, QG) correctly
- [ ] Stack-specific tool/command references are resolved (not [PLACEHOLDER])
- [ ] Skill 1 (implement) includes Manual Tasks field in Step Completion Report
- [ ] Skill 1 (implement) produces Wave Completion Summary as final output
- [ ] Skill 2 (gate) includes manual tasks pending check and consumes Wave Completion Summary
- [ ] Skill 10 (parallel) includes manual task aggregation across subagents

**Manual Tasks Tracker:**
- [ ] `MANUAL_TASKS.md` template file included at project root
- [ ] `.claude/rules/manual-tasks.md` present with complete format and logging rules
- [ ] Master CLAUDE.md includes Manual Tasks Tracker section
- [ ] Agent-specific CLAUDE.md files reference manual tasks convention

**General:**
- [ ] `.gitignore` includes `CLAUDE.local.md`, `settings.local.json`, `worktrees/`,
  `backups/`
- [ ] No placeholder text remains (except in .env.example)
- [ ] No real credentials in .env.example or mcp-config.json

---

## References

- `references/structure.md` — Detailed specification for every file in the scaffold,
  including full content templates for all 20 skills, all subagent definitions, all hook
  scripts, all rule files, and all supporting documentation
