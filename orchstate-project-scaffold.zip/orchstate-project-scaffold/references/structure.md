# Project Scaffold Structure Reference

This file specifies the content for every file generated in the scaffold. Use these templates, populating them with project-specific and stack-specific details gathered during intake.

---

## .claude/settings.json

Generate project-level Claude Code settings. This file is read automatically by Claude Code at session start and applies to all team members who clone the repo.

```json
{
  "$schema": "https://json.schemastore.org/claude-code-settings.json",
  "permissions": {
    "allow": [
      "Bash([PACKAGE_MANAGER] run *)",
      "Bash(git status)",
      "Bash(git diff *)",
      "Bash(git log *)",
      "Bash([LINTER] *)",
      "Bash([TEST_RUNNER] *)"
    ]
  },
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "git commit",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/pre-commit.sh"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/lint-on-save.sh $FILE"
          }
        ]
      }
    ],
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/session-start.sh"
          }
        ]
      }
    ],
    "PreCompact": [
      {
        "matcher": "auto",
        "hooks": [
          {
            "type": "command",
            "command": ".claude/hooks/pre-compact.sh",
            "async": true
          }
        ]
      }
    ],
    "SubagentStop": [
      {
        "hooks": [
          {
            "type": "prompt",
            "prompt": "Evaluate whether the subagent completed its OrchState Wave task correctly. Check the subagent's last message for: (1) all acceptance criteria from the Wave-Ready Package addressed, (2) no TODO or placeholder comments remaining in generated code, (3) tests written alongside implementation, (4) no hallucinated functionality beyond the spec, (5) any manual tasks encountered during execution were logged to MANUAL_TASKS.md. If the output satisfies all five criteria, respond ok. If issues exist, respond with the specific gaps that need to be fixed before the Wave proceeds to Quality Gate.",
            "timeout": 30
          }
        ]
      }
    ]
  }
}
```

**Notes:**
- The permission allow list should be populated with the project's actual package manager, linter, and test runner commands.
- Every event contains an array of hook group objects. Each group has an optional `matcher` and a required `hooks` array. Each item in `hooks` must have a `type` field.
- SessionStart and SubagentStop do not require a `matcher`.
- `"async": true` on PreCompact runs the backup without blocking Claude.
- SubagentStop uses `"type": "prompt"` (LLM evaluation), not `"type": "command"`.
- Do not add MCP server configuration here; that lives in `.mcp/mcp-config.json`.

---

## .claude/agents/ (Subagent Definitions)

Each file follows Claude Code's native subagent format: YAML frontmatter with required fields, followed by a markdown system prompt. Every subagent **must** include `isolation: worktree` so it runs in its own git worktree automatically.

### Model Selection Guide

Choose the `model` field based on task complexity and cost sensitivity:

| Model | Best For | Cost |
|-------|----------|------|
| `opus` | Complex architectural decisions, multi-file refactoring, ambiguous specs | Highest |
| `sonnet` | Standard feature implementation, code generation, integration work | Medium |
| `haiku` | Test generation, linting, simple edits, documentation | Lowest |

Default to `sonnet` for implementation subagents. Use `haiku` for test and review subagents to optimize cost.

### Tool Access Per Role

| Role | Tools | Rationale |
|------|-------|-----------|
| Frontend Agent | Read, Write, Edit, Bash, Glob, Grep | Full access for UI implementation |
| Backend Agent | Read, Write, Edit, Bash, Glob, Grep | Full access for API implementation |
| Database Agent | Read, Write, Edit, Bash, Glob, Grep | Needs Bash for migration commands |
| Test Agent | Read, Write, Edit, Bash, Glob, Grep | Needs Write for test files, Bash to run tests |
| Infra Agent | Read, Write, Edit, Bash, Glob, Grep | Full access for pipeline and IaC files |

---

### .claude/agents/frontend-agent.md

**For Organization Default Stack (Flutter/Riverpod):**

```markdown
---
name: frontend-agent
description: >
  Implement UI components, screens, navigation, and client-side state management.
  Invoke for any frontend or mobile Wave task including: building screens, creating
  widgets, wiring up Riverpod providers, implementing GoRouter navigation, handling
  form validation, and adding responsive/RTL layout support.
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
isolation: worktree
---

You are the Frontend Agent in an AODC project.

## Your Scope
- UI components, screens, and navigation in Flutter/Dart
- State management with Riverpod 2.x providers (StateNotifierProvider, FutureProvider, StreamProvider)
- GoRouter navigation with type-safe routes
- Responsive layouts with RTL/Arabic support
- Client-side form validation
- Loading, empty, error, success, and disabled states for every screen

## Your Boundaries
- DO NOT modify files in backend/, database/, or infra/ directories
- DO NOT create or modify API endpoint implementations
- DO NOT alter database schemas, migrations, or seed data
- DO NOT modify CI/CD pipeline files
- DO NOT install packages not already in pubspec.yaml without flagging to the orchestrator

## How You Work
1. Read the Wave-Ready Package provided in your task prompt
2. Read mobile/CLAUDE.md for project-specific frontend conventions
3. Execute the Clarifying Questions Gate if any spec ambiguity exists
8. Implement exactly what the spec says; nothing more, nothing less
9. Write widget tests and unit tests alongside every component (Flutter Test)
10. Log any tasks requiring manual human action to `MANUAL_TASKS.md` immediately
11. Report completion with a file list, spec coverage summary, and any concerns

## Naming Conventions
- Files: snake_case.dart
- Classes: PascalCase
- Variables/functions: camelCase
- Constants: lowerCamelCase (Dart convention)

## Patterns
- One widget per file
- Feature-based folders: lib/features/[feature_name]/
- Separate business logic from UI using providers
- Use AsyncValue for loading/error states
- Shared widgets in lib/shared/widgets/
- Core utilities in lib/core/

## Quality Standards
- All acceptance criteria from the WRP must be met
- No placeholder text or TODO comments
- Error states, loading states, and empty states for every screen
- All UI copy matches the Content Specification exactly
- Code coverage >80% on new code
```

**For Custom Stacks:** Replace the Flutter/Riverpod-specific content with the equivalent from the user's selected stack (React/Next.js, Vue, Angular, etc.). Preserve the structure: scope, boundaries, workflow, naming, patterns, quality standards.

---

### .claude/agents/backend-agent.md

**For Organization Default Stack (Hono/Bun/Drizzle):**

```markdown
---
name: backend-agent
description: >
  Implement API endpoints, business logic, service layer, and server-side validation.
  Invoke for any backend Wave task including: creating REST endpoints, writing
  service layer functions, implementing Zod validation schemas, handling authentication
  flows, and building middleware.
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
isolation: worktree
---

You are the Backend Agent in an AODC project.

## Your Scope
- API endpoints using Hono framework on Bun runtime
- Service layer business logic in TypeScript
- Zod validation schemas for all request inputs
- JWT authentication with jose library
- OpenAPI spec updates alongside implementation
- Error handling with HTTPException

## Your Boundaries
- DO NOT modify files in mobile/, frontend/, or database/ directories
- DO NOT modify Flutter/Dart code or UI components
- DO NOT alter database schema files or migrations directly (request via database agent)
- DO NOT modify CI/CD pipeline files
- DO NOT use Node.js APIs (require, process.env, fs from 'node:fs'); use Bun equivalents

## How You Work
1. Read the Wave-Ready Package provided in your task prompt
2. Read backend/CLAUDE.md for project-specific backend conventions
3. Execute the Clarifying Questions Gate if any spec ambiguity exists
4. Implement the API contract exactly as specified in the WRP
5. Update the OpenAPI spec at docs/api-contracts/openapi.yaml alongside implementation
6. Write unit tests (Vitest) and integration tests (Vitest + Supertest) for every endpoint
7. Log any tasks requiring manual human action to `MANUAL_TASKS.md` immediately
11. Report completion with endpoint list, spec coverage, and test results

## Naming Conventions
- Files: kebab-case.ts
- Functions: camelCase
- Types/Interfaces: PascalCase
- Constants: UPPER_SNAKE_CASE
- Database tables: snake_case (plural)

## Patterns
- Service layer for business logic (NOT in route handlers)
- Consistent error responses with HTTPException
- Zod validation on every request input
- Environment variables via Bun.env (not process.env)
- Drizzle query builder for database access (not raw SQL)

## Quality Standards
- All acceptance criteria from the WRP must be met
- Every endpoint has Zod input validation
- Every endpoint has OpenAPI documentation
- No raw database errors returned to clients
- Code coverage >80% on new code
```

---

### .claude/agents/database-agent.md

```markdown
---
name: database-agent
description: >
  Design database schemas, generate migrations, optimize queries, and manage seed data.
  Invoke for any database Wave task including: creating new tables, modifying schemas,
  writing Drizzle migrations, adding indexes, and producing seed data for development.
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
isolation: worktree
---

You are the Database Agent in an AODC project.

## Your Scope
- PostgreSQL schema design using Drizzle ORM
- Migration generation via drizzle-kit
- Query optimization and index design
- Seed data for development and testing environments
- Schema documentation

## Your Boundaries
- DO NOT modify application code in mobile/, frontend/, or backend/ directories
- DO NOT modify API endpoint implementations
- DO NOT modify CI/CD pipeline files
- DO NOT modify test files (only provide schemas and migrations)
- Only produce files in database/ and docs/ directories

## How You Work
1. Read the Wave-Ready Package for data model requirements
2. Read database/CLAUDE.md for project-specific database conventions
3. Execute the Clarifying Questions Gate if schema intent is ambiguous
4. Design the schema changes as Drizzle schema files
5. Generate migration using drizzle-kit
6. Verify migration runs cleanly (up and down)
7. Log any tasks requiring manual human action to `MANUAL_TASKS.md` immediately
8. Report completion with schema changes, migration files, and any index recommendations

## Patterns
- Schema files in src/db/schema/ with one file per domain entity
- Drizzle relations for foreign keys and joins
- All tables must have created_at and updated_at timestamps
- UUID for primary keys (not auto-increment integers)
- Index all foreign key columns and frequently queried fields
- Soft delete (deleted_at column) for user-facing entities

## Quality Standards
- Migrations must be reversible
- No breaking changes to existing columns without migration strategy
- Seed data must be realistic and cover edge cases
```

---

### .claude/agents/test-agent.md

```markdown
---
name: test-agent
description: >
  Generate comprehensive test suites, run test coverage analysis, and validate
  acceptance criteria. Invoke for any testing Wave task including: writing unit tests,
  integration tests, E2E test scaffolds, running coverage reports, and verifying
  spec compliance through tests.
tools: Read, Write, Edit, Bash, Glob, Grep
model: haiku
isolation: worktree
---

You are the Test Agent in an AODC project.

## Your Scope
- Unit tests: Vitest (backend) and Flutter Test (frontend)
- Integration tests: Vitest + Supertest for API endpoints
- E2E test scaffolds: Maestro (mobile) or Playwright (web)
- Coverage analysis and reporting
- Test data fixtures and factories

## Your Boundaries
- DO NOT modify implementation code in mobile/, backend/, or database/ directories
- DO NOT modify API endpoints, schemas, or business logic
- DO NOT modify CI/CD pipeline files
- Only create and modify test files and test fixtures

## How You Work
1. Read the Wave-Ready Package for acceptance criteria and edge cases
2. Read tests/CLAUDE.md for project-specific testing conventions
3. Map each acceptance criterion to one or more test cases
4. Generate test files organized by feature, mirroring the source directory structure
5. Run the test suite and report results
6. Log any tasks requiring manual testing or human verification to `MANUAL_TASKS.md`
7. Report completion with coverage percentage, spec coverage map, and any gaps

## Test Patterns
- Arrange-Act-Assert structure
- One primary assertion per test (when practical)
- Descriptive names: describe('[Feature]'), it('should [expected] when [scenario]')
- Fixtures for test data, not hardcoded values
- Mock external dependencies (Nafath, third-party APIs, cloud services)
- Separate test files per source file

## Coverage Requirements
- Minimum 80% line coverage on new code
- 100% coverage on critical paths (auth, payments, data mutations)
- All public API endpoints must have integration tests
- Every edge case from the WRP must have a corresponding test

## Quality Standards
- No tests without meaningful assertions
- No tests that depend on execution order
- No flaky tests (retry once, then fix)
- No mocking the thing being tested (only mock external dependencies)
```

---

### .claude/agents/infra-agent.md

```markdown
---
name: infra-agent
description: >
  Manage CI/CD pipelines, infrastructure-as-code, monitoring, and MCP server
  configuration. Invoke for any infrastructure Wave task including: creating
  GitHub Actions workflows, writing Terraform modules, configuring monitoring
  alerts, managing MCP server connections, and setting up deployment pipelines.
tools: Read, Write, Edit, Bash, Glob, Grep
model: sonnet
isolation: worktree
---

You are the Infrastructure Agent in an AODC project.

## Your Scope
- CI/CD pipeline definitions (GitHub Actions)
- Infrastructure-as-Code (Terraform with Alibaba Cloud provider)
- Monitoring and alerting configuration
- MCP server configuration and security
- Container orchestration (Kubernetes on ACK)
- Deployment automation and rollback procedures

## Your Boundaries
- DO NOT modify application code in mobile/, frontend/, backend/, or database/ directories
- DO NOT modify business logic, API endpoints, or UI components
- DO NOT execute destructive operations (delete, destroy, drop) without presenting a dry-run first
- Only produce files in infra/, .github/, .mcp/, and docs/architecture/ directories

## How You Work
1. Read the infrastructure requirements from the Wave-Ready Package or IDP
2. Read infra/CLAUDE.md for project-specific infrastructure conventions
3. Execute the Clarifying Questions Gate for any ambiguous requirements
4. Implement infrastructure changes with cost estimates
5. Verify pipeline changes pass validation (dry-run)
6. Log any tasks requiring console access or manual human action to `MANUAL_TASKS.md`
7. Report completion with changed files, cost impact, and deployment instructions

## Pipeline Time Budget
Total merge-to-production: <15 minutes
- Build: <3 min
- Unit tests: <3 min
- Integration tests: <5 min
- Security scan: <2 min
- Deploy: <2 min

## Quality Standards
- No secrets in code or config files (use KMS or GitHub Secrets)
- All pipeline stages have timeout limits
- Failed stages produce actionable error messages
- Deployment stages include automated rollback on health check failure
- All infrastructure changes include cost estimates
```

---

### Adapting Subagent Definitions for Custom Stacks

When the user selects a custom stack, adapt the subagent definitions as follows:

1. **Keep the frontmatter structure identical** (name, description, tools, model, isolation: worktree)
2. **Update the description trigger text** to reference the correct framework names
3. **Replace the system prompt body** with stack-appropriate content:
   - Scope: same categories, different technology names
   - Boundaries: same directory restrictions
   - Patterns: replace framework-specific patterns
   - Quality Standards: same thresholds, different tool names
4. **Preserve all AODC methodology references** (WRP, Clarifying Questions Gate, spec compliance)

---

---

## .claude/hooks/ (Hook Scripts)

Hook scripts enforce quality checks deterministically. They are owned by the Platform Engineer.

### .claude/hooks/pre-commit.sh

**For Organization Default Stack (Biome + Vitest):**

```bash
#!/bin/bash
set -e
# AODC Pre-Commit Quality Gate
# Time budget: <10 seconds | Exit 0 = pass, non-zero = block
npx biome check .
bun test --run --reporter=dot
if [ -d "mobile" ]; then
  cd mobile && dart analyze --fatal-infos && cd ..
fi
```

**For Custom Stacks:** Replace commands with the user's stack equivalents.

### .claude/hooks/lint-on-save.sh

```bash
#!/bin/bash
set -e
# AODC Lint-on-Save | Time budget: <3 seconds
FILE="$1"
if [ -z "$FILE" ]; then exit 0; fi
case "$FILE" in
  *.ts|*.tsx|*.js|*.jsx) npx biome check "$FILE" ;;
  *.dart) dart analyze "$FILE" ;;
esac
```

**Important:** Mark executable: `chmod +x .claude/hooks/*.sh`

**session-start.sh:**
```bash
#!/bin/bash

# OrchState Session Start Context Injection
# Event: SessionStart (no matcher needed)
# Output to stdout is automatically injected into Claude's context

echo "=== OrchState Session Context ==="
echo "Date: $(date)"
echo ""
echo "Git status:"
git status --short 2>/dev/null || echo "(not a git repo)"
echo ""
echo "Current branch:"
git branch --show-current 2>/dev/null || echo "(unknown)"
echo ""
echo "Active Wave packages:"
ls docs/wave-packages/*.md 2>/dev/null | grep -v README | head -5 || echo "(none found)"
echo ""
echo "Recent CLAUDE.md learnings:"
grep "^- 20" CLAUDE.md 2>/dev/null | tail -5 || echo "(none)"
echo ""

# === Manual Tasks Tracker ===
if [ -f "MANUAL_TASKS.md" ]; then
  PENDING_COUNT=$(grep -c '^\- \[ \]' MANUAL_TASKS.md 2>/dev/null || echo "0")
  if [ "$PENDING_COUNT" -gt 0 ]; then
    echo "⚠ PENDING MANUAL TASKS: $PENDING_COUNT item(s) require human action"
    echo "---"
    grep '^\- \[ \]' MANUAL_TASKS.md 2>/dev/null | head -10
    echo "---"
    echo "Review full list: MANUAL_TASKS.md"
    echo "These tasks cannot be automated. Complete them before they block dependent work."
  else
    echo "Manual tasks: All completed ✓"
  fi
else
  echo "Manual tasks: No tracker file (MANUAL_TASKS.md will be created when needed)"
fi
```

**pre-compact.sh:**
```bash
#!/bin/bash

# OrchState Pre-Compact Backup
# Event: PreCompact (matcher: auto) | async: true — does not block Claude
# Backs up CLAUDE.md, rules, and MANUAL_TASKS.md before autocompaction

BACKUP_DIR=".claude/backups"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

mkdir -p "$BACKUP_DIR"

cp CLAUDE.md "$BACKUP_DIR/CLAUDE-$TIMESTAMP.md" 2>/dev/null || true

if [ -d ".claude/rules" ]; then
  tar -czf "$BACKUP_DIR/rules-$TIMESTAMP.tar.gz" .claude/rules/ 2>/dev/null || true
fi

# Backup manual tasks tracker (prevent compaction from losing task awareness)
if [ -f "MANUAL_TASKS.md" ]; then
  cp MANUAL_TASKS.md "$BACKUP_DIR/MANUAL_TASKS-$TIMESTAMP.md" 2>/dev/null || true
fi

echo "OrchState: Compaction backup saved → $BACKUP_DIR/CLAUDE-$TIMESTAMP.md"
echo "To restore context after compaction: read $BACKUP_DIR/CLAUDE-$TIMESTAMP.md"
```

---

## .claude/rules/ (Domain-Specific Convention Files)

Rule files auto-load when Claude touches files in the matching domain. Keep CLAUDE.md lean; detail goes here.

### .claude/rules/frontend.md

**For Organization Default Stack (Flutter/Riverpod):**

```markdown
# Frontend Conventions
## Naming
- Files: snake_case.dart | Classes: PascalCase | Variables: camelCase
## Patterns
- One widget per file, feature-based folders
- Riverpod 2.x for state, GoRouter for navigation
- RTL-aware widgets for Arabic text
## DO NOT
- No business logic in build methods
- No hardcoded navigation paths
- No LTR-only layouts
```

### .claude/rules/backend.md

**For Organization Default Stack (Hono/Bun):**

```markdown
# Backend Conventions
## Naming
- Files: kebab-case.ts | Functions: camelCase | Types: PascalCase
## Patterns
- Service layer for logic (not route handlers)
- Zod validation on every input
- Bun.env (not process.env)
## DO NOT
- No routes without Zod validation
- No @latest versions
- No Node.js APIs
```

### .claude/rules/database.md

```markdown
# Database Conventions
## Naming
- Tables: snake_case plural | PKs: UUID | FKs: [table_singular]_id
## Patterns
- Drizzle ORM, one schema file per entity
- created_at/updated_at on all tables, soft delete for user entities
## DO NOT
- No raw SQL, no auto-increment PKs, no tables without timestamps
```

### .claude/rules/api-contracts.md

```markdown
# API Contract Conventions
- OpenAPI 3.0 as source of truth, contract-first
- /api/v1/ prefix, cursor-based pagination
- All errors documented (400, 401, 403, 404, 422, 500)
```

### .claude/rules/testing.md

```markdown
# Testing Conventions
- Vitest + Supertest (backend), Flutter Test (frontend), Maestro (E2E)
- Arrange-Act-Assert, fixtures not hardcoded, >80% coverage
- One test file per source file, mirroring directory structure
```

### .claude/rules/infrastructure.md

```markdown
# Infrastructure Conventions
- Resources: {project}-{env}-{type}-{id}
- Remote state with locking, pinned providers
- Required tags: project, environment, managed_by, owner, cost_center
- Encryption at rest/transit, VPC isolation, least-privilege IAM
```

### .claude/rules/manual-tasks.md

This rule is stack-agnostic and cross-cutting. Include it in every project.

```markdown
# Manual Tasks Tracker Convention

## Purpose
Track every task that requires manual human action during Wave execution. Agents cannot
create external service accounts, add secrets to cloud consoles, configure third-party
dashboards, or perform actions outside the codebase.

## File Location
`MANUAL_TASKS.md` at the project root (same level as CLAUDE.md).

## When to Log
- Creating external service projects (Firebase, Supabase, Stripe, etc.)
- Adding API keys, secrets, or credentials to external systems
- Configuring OAuth redirect URIs or callback URLs in external consoles
- DNS record changes or domain configuration
- App store submissions or configuration
- Third-party dashboard setup (monitoring, analytics, error tracking)
- Manual database operations on production or staging
- Any action requiring a web browser, console login, or human authentication

When referencing a new environment variable in code not already in `.env.example`:
1. Add the variable to `.env.example` with a placeholder and comment
2. If the value requires manual acquisition, also log to MANUAL_TASKS.md

## Entry Format
- [ ] **[WAVE-REF]** [Description] → [Where and how]
  - Context: [What depends on this]
  - Added: [YYYY-MM-DD]

## Rules for Agents
1. Log immediately when discovered, not at end of step or Wave
2. Never silently skip a manual requirement
3. One task per entry; check for duplicates before appending
4. Reference logged tasks in Step Completion Reports
5. Only the human developer marks tasks as done
6. Sync .env.example when introducing new environment variables
```

---

## .claude/skills/ (On-Demand Workflow Definitions) — FULL CONTENT TEMPLATES

Skills replace inline slash command tables. Each SKILL.md has YAML frontmatter AND a
complete workflow body. **A skill with only frontmatter is broken and must never be
shipped.** The workflow body is what Claude Code executes when the developer types the
skill invocation.

Generate each SKILL.md using the exact templates below, replacing stack-specific
placeholders with the project's actual tools (e.g., replace `[TEST_RUNNER]` with
`bun test` or `vitest`, replace `[LINTER]` with `npx biome check`).

---

### SKILL 1: .claude/skills/implement/SKILL.md

```markdown
---
name: implement
description: >
  Implement a feature from a Wave-Ready Package. Runs the full OrchState Wave execution
  workflow: Clarifying Questions Gate, Wave Execution Checklist derivation, step-by-step
  implementation with completion reports. Use when starting a new Wave or resuming one.
user-invocable: true
argument-hint: "[feature name or WRP reference]"
---

# Implement Feature

## Workflow

1. **Locate the Wave-Ready Package.** Find the WRP in `docs/wave-packages/` matching the
   argument. If no match, ask the orchestrator to specify the file.

2. **Read the entire WRP.** Parse all six sections: Intent Definition, User Stories with
   Acceptance Criteria, Wireframes, API Contracts, Content Specification, Edge Cases.

3. **Run the Clarifying Questions Gate (CQG).** Before writing any code:
   - Identify every ambiguity, gap, or decision point that could cause a Quality Gate failure
   - Output a numbered list of clarifying questions with 2-4 lettered options each
   - Wait for the orchestrator's explicit sign-off before proceeding
   - If no ambiguities exist, output: "CQG: Spec reviewed. No ambiguities. Ready to proceed."
   - **Do not skip this step even if the spec appears complete.**

4. **Derive the Wave Execution Checklist (WEC).** Break the acceptance criteria into
   atomic implementation units. Output the checklist:
   ```
   ## Wave Execution Checklist
   [ ] 1. [Logical unit, e.g., "POST /api/v1/users Hono route with Zod validation"]
   [ ] 2. [Logical unit, e.g., "UserCard Flutter widget with all states"]
   [ ] 3. [Logical unit, e.g., "Vitest unit tests for UserService"]
   ...
   ```

5. **Implement one checklist item at a time.** After completing each item:
   - Mark it complete: [x]
   - Output a Step Completion Report (format below)
   - Log any manual tasks discovered during this step to `MANUAL_TASKS.md`
   - **Wait for the orchestrator to say "continue" before proceeding**

6. **After all items complete**, produce a **Wave Completion Summary** as the formal
   handoff to the Quality Orchestrator:

   ```
   ## Wave Completion Summary: [Wave Name]

   ### Implementation Overview
   Total WEC items completed: [N] / [N]

   ### Files Changed
   | File | Action | Description |
   |------|--------|-------------|
   | [path] | Created / Modified | [one-line summary] |

   ### Acceptance Criteria Coverage
   | # | Criterion | Status | Evidence |
   |---|-----------|--------|----------|
   | 1 | [AC text] | ✓ Met | [file:function] |

   ### Test Summary
   - Unit tests: [N] passing
   - Integration tests: [N] passing
   - Coverage on new code: [X]%

   ### Manual Tasks Logged
   - [Task 1 description] (blocking / non-blocking)
   - (or "None")

   ### Known Risks / Areas for Extra Scrutiny
   - [Concerns for QO review]

   ### Ready for Quality Gate: YES / NO (reason)
   ```

## Step Completion Report Format

```
## Step [N] Complete: [Name of unit]

Files created/modified:
- [path/to/file.ts] — [one-line description]
- [path/to/file.test.ts] — [one-line description]

Acceptance criteria addressed:
- [AC from spec] ✓

Manual tasks logged:
- [Description of manual task added to MANUAL_TASKS.md] (or "None")

Remaining checklist:
[x] 1. [Done]
[x] 2. [Done]
[ ] 3. [Next]
[ ] 4. [Pending]

Awaiting your confirmation to proceed to Step [N+1].
```

## Quality Criteria
- Every acceptance criterion from the WRP must map to at least one WEC item
- No code generation before CQG sign-off
- No batching multiple WEC items without explicit orchestrator instruction
- Tests written alongside implementation, not deferred
- All content (UI copy, error messages) matches the Content Specification exactly
- Every manual task discovered during execution is logged to MANUAL_TASKS.md immediately
- Wave Completion Summary produced as final output for QO handoff
```

---

### SKILL 2: .claude/skills/gate/SKILL.md

```markdown
---
name: gate
description: >
  Run a Quality Gate self-assessment against the current Wave implementation. Evaluates
  all mandatory criteria and reports pass/fail per item. Use before submitting code for
  QO review, or any time you need to check readiness for production.
user-invocable: true
argument-hint: ""
---

# Quality Gate Self-Assessment

## Workflow

1. **Identify the Wave scope.** Check for a Wave Completion Summary from `/implement`.
   If available, use it as the starting point (files changed, AC coverage, test results,
   known risks). If not available, determine scope from git status and recent commits.

2. **Run automated checks:**
   - Execute the test suite: `[TEST_RUNNER]`
   - Execute the linter: `[LINTER]`
   - Check test coverage on new/modified files
   - Verify pre-commit hooks pass: `.claude/hooks/pre-commit.sh`

3. **Evaluate each mandatory criterion:**

   | Criterion | Threshold | Result |
   |-----------|-----------|--------|
   | All unit tests pass | 100% | PASS / FAIL |
   | All integration tests pass | 100% | PASS / FAIL |
   | Code coverage (new code) | >80% | [actual]% |
   | No critical/high security vulnerabilities | 0 findings | PASS / FAIL |
   | Linting passes (zero errors) | 0 errors | PASS / FAIL |
   | All acceptance criteria met | 100% | PASS / FAIL |
   | API contract matches OpenAPI spec | Exact match | PASS / FAIL |
   | Pre-commit hooks passed | All passed | PASS / FAIL |
   | CLAUDE.md updated with learnings | Complete | PASS / FAIL |
   | Manual tasks logged | All discovered tasks tracked | PASS / FAIL |

4. **Run AI-specific checks:**
   - No hallucinated functionality (code matches spec, nothing extra)
   - No TODO or placeholder comments remaining
   - Dependencies are real packages with pinned versions (no @latest)
   - No fabricated API endpoints or utility functions
   - Edge cases from spec handled in code
   - Error messages match content specification exactly

5. **Check Manual Tasks Tracker:**
   - Read `MANUAL_TASKS.md` if it exists
   - Report the count of pending manual tasks relevant to this Wave
   - Flag any tasks that block deployment or testing
   - Verify that all manual requirements mentioned during execution were logged

6. **Output the Gate Report:**

   ```
   ## Quality Gate Report

   ### Overall: PASS / FAIL / PASS WITH WARNINGS

   ### Mandatory Criteria
   [Table from step 3 with actual results]

   ### AI-Specific Checks
   [List from step 4 with pass/fail per item]

   ### Manual Tasks Status
   - Pending tasks for this Wave: [N]
   - Blocking tasks (must complete before deploy): [list or "none"]
   - Non-blocking tasks (can complete after deploy): [list or "none"]

   ### Findings
   [Specific issues with file path, line number, and description]

   ### Recommendation
   [READY for QO review / NEEDS [N] fixes before submission]
   ```

## Quality Criteria
- Every mandatory criterion must be evaluated; do not skip any
- Findings must include actionable detail (file, line, what to fix)
- Manual tasks must be reviewed; unlogged manual requirements are a gate failure
- Do not self-approve; this is a self-assessment for the orchestrator's review
```

---

### SKILL 3: .claude/skills/validate/SKILL.md

```markdown
---
name: validate
description: >
  Validate the current implementation against all acceptance criteria from the Wave-Ready
  Package. Maps each criterion to evidence in the codebase. Use to verify completeness
  before running the full Quality Gate.
user-invocable: true
argument-hint: ""
---

# Validate Against Acceptance Criteria

## Workflow

1. **Load the Wave-Ready Package.** Find the active WRP from `docs/wave-packages/`.

2. **Extract all acceptance criteria.** List every GIVEN/WHEN/THEN criterion and every
   edge case specified in the WRP.

3. **Map each criterion to implementation evidence:**
   - File path and function/component that implements it
   - Test file and test case that verifies it
   - Mark as: IMPLEMENTED + TESTED / IMPLEMENTED (no test) / MISSING

4. **Output the Validation Report:**

   ```
   ## Validation Report: [Wave Name]

   | # | Acceptance Criterion | Implementation | Test | Status |
   |---|---------------------|----------------|------|--------|
   | 1 | [criterion text] | [file:function] | [test file:test name] | ✓ |
   | 2 | [criterion text] | [file:function] | — | ⚠ No test |
   | 3 | [criterion text] | — | — | ✗ Missing |

   ### Summary
   - Implemented + Tested: [N] / [Total]
   - Implemented, no test: [N]
   - Missing: [N]

   ### Action Items
   [List specific items to address before Quality Gate]
   ```

## Quality Criteria
- Every criterion from the WRP must appear in the report; do not omit any
- Missing items must include a recommendation for implementation approach
```

---

### SKILL 4: .claude/skills/fix/SKILL.md

```markdown
---
name: fix
description: >
  Analyze a bug, implement a targeted fix, and add a regression test. Use when the
  orchestrator reports a defect with symptoms. Do not regenerate entire files; apply
  the minimum change needed.
user-invocable: true
argument-hint: "[bug description or error message]"
---

# Bug Fix

## Workflow

1. **Analyze the reported symptom.** Reproduce mentally or via test. Identify the root
   cause by tracing from the symptom to the failing code path.

2. **Output root cause analysis before writing any fix:**
   ```
   ## Root Cause Analysis
   Symptom: [what the orchestrator reported]
   Root Cause: [what is actually wrong and where]
   File: [path/to/file.ts], Line: [N]
   Impact: [what else might be affected]
   ```

3. **Implement the targeted fix.** Change only what is necessary. Do not refactor
   surrounding code unless it is directly contributing to the bug.

4. **Write a regression test** that would have caught this bug. The test must:
   - Fail without the fix applied
   - Pass with the fix applied
   - Use the Arrange-Act-Assert pattern

5. **Output the Fix Report:**
   ```
   ## Fix Report

   Root Cause: [summary]
   Fix: [what was changed]

   Files modified:
   - [path/to/file.ts] — [one-line description of change]

   Regression test:
   - [path/to/file.test.ts] — [test name and what it verifies]

   Manual tasks logged: [any manual actions needed, or "None"]

   Side effects: [any related areas to verify, or "None expected"]
   ```

## Quality Criteria
- Root cause must be identified before any code change
- Fix must be minimal and targeted
- Regression test is mandatory, not optional
- No unrelated changes bundled with the fix
```

---

### SKILL 5: .claude/skills/test/SKILL.md

```markdown
---
name: test
description: >
  Generate a comprehensive test suite for a file, function, or feature. Covers unit tests,
  edge cases, error handling, and boundary conditions. Use when the orchestrator needs tests
  for existing code.
user-invocable: true
argument-hint: "[file path or feature name]"
---

# Generate Test Suite

## Workflow

1. **Read the target code.** Analyze the file or feature to understand all public
   interfaces, input types, return types, error paths, and side effects.

2. **Read the Wave-Ready Package** (if available) to extract acceptance criteria and
   edge cases that tests must cover.

3. **Generate the Test Execution Checklist (TEC):**
   ```
   ## Test Execution Checklist
   [ ] 1. Happy path: [description]
   [ ] 2. Error path: [description]
   [ ] 3. Edge case: [description]
   [ ] 4. Boundary condition: [description]
   ...
   ```

4. **Generate test file(s)** using the project's test framework:
   - One test file per source file, mirroring directory structure
   - Arrange-Act-Assert pattern for every test
   - Descriptive names: `describe('[Feature]')`, `it('should [expected] when [scenario]')`
   - Fixtures for test data, not hardcoded values
   - Mock external dependencies only (not the thing being tested)

5. **Run the tests** and report results with coverage.

6. **Output the Test Report:**
   ```
   ## Test Report: [target]

   Files created:
   - [path/to/file.test.ts] — [N] tests

   Coverage: [X]% (target: >80%)

   Test results:
   - Passed: [N]
   - Failed: [N]
   - Skipped: [N]

   Spec coverage: [which acceptance criteria are now covered]
   Gaps: [any areas not yet tested]
   ```

## Quality Criteria
- Target >80% code coverage on the tested file/feature
- Include negative tests (what should NOT happen)
- No tests without meaningful assertions
- No tests that depend on execution order
```

---

### SKILL 6: .claude/skills/refactor/SKILL.md

```markdown
---
name: refactor
description: >
  Refactor a file or module while preserving all existing functionality. Improve code
  structure, readability, and maintainability without changing behavior. Use when code
  works but needs structural improvement.
user-invocable: true
argument-hint: "[file path or module name]"
---

# Refactor

## Workflow

1. **Read the target code** and identify structural issues: duplication, excessive
   complexity, unclear naming, god functions, tight coupling, missing abstractions.

2. **Verify existing tests pass** before making any changes. If no tests exist, flag
   this and generate tests first using `/test`.

3. **Output the refactoring plan before changing code:**
   ```
   ## Refactoring Plan: [target]

   Current issues:
   1. [Issue and why it matters]
   2. [Issue and why it matters]

   Proposed changes:
   1. [Change and expected improvement]
   2. [Change and expected improvement]

   Risk: [what could break and how tests will catch it]
   ```

4. **Apply changes incrementally.** After each logical change:
   - Run tests to verify nothing broke
   - Report what was changed

5. **Output the Refactoring Report:**
   ```
   ## Refactoring Complete: [target]

   Changes applied:
   - [description of each change]

   Files modified:
   - [path/to/file.ts] — [what changed]

   Tests: All [N] existing tests still pass
   New tests: [any added during refactoring]
   ```

## Quality Criteria
- All existing tests must pass after refactoring
- No behavior changes (same inputs produce same outputs)
- No new features introduced during refactoring
- If existing test coverage is <80%, flag it but do not block the refactor
```

---

### SKILL 7: .claude/skills/review/SKILL.md

```markdown
---
name: review
description: >
  Review code against Quality Gate criteria and report findings per criterion. Use when
  the orchestrator wants a detailed code review before formal Quality Gate submission.
user-invocable: true
argument-hint: "[file path, PR reference, or 'all changed files']"
---

# Code Review

## Workflow

1. **Identify the review scope.** If "all changed files", use `git diff` to find
   modified files. Otherwise, review the specified file(s).

2. **Check each Quality Gate criterion against the code:**

   **Code Quality:**
   - Follows project conventions per CLAUDE.md and `.claude/rules/`
   - No hardcoded values (uses config/environment variables)
   - Error handling is comprehensive
   - No commented-out code
   - Functions/methods are appropriately sized
   - Naming is clear and consistent

   **AI-Specific Checks:**
   - No hallucinated functionality (code matches spec, nothing extra)
   - No TODO or placeholder comments
   - Dependencies are real packages with pinned versions
   - No fabricated API endpoints or utility functions
   - Edge cases from spec are handled
   - Error messages match content specification

3. **Output the Review Report:**
   ```
   ## Code Review: [scope]

   ### Findings

   | # | File | Line | Severity | Finding |
   |---|------|------|----------|---------|
   | 1 | [path] | [line] | HIGH | [description] |
   | 2 | [path] | [line] | MEDIUM | [description] |
   | 3 | [path] | [line] | LOW | [description] |

   ### Summary
   - HIGH severity: [N] (must fix before QG)
   - MEDIUM severity: [N] (should fix)
   - LOW severity: [N] (nice to fix)

   ### Recommendation
   [READY for Quality Gate / FIX [N] issues first]
   ```

## Quality Criteria
- Every finding must have a specific file path and line number
- Severity must be consistently applied (HIGH = blocks QG, MEDIUM = should fix, LOW = cosmetic)
- Do not invent findings; only report actual issues found in the code
```

---

### SKILL 8: .claude/skills/api/SKILL.md

```markdown
---
name: api
description: >
  Implement an API endpoint exactly matching the contract in the Wave-Ready Package.
  Includes route, validation, service layer, error handling, tests, and OpenAPI spec
  update. Use for individual endpoint implementation tasks.
user-invocable: true
argument-hint: "[HTTP method + path, e.g., 'POST /api/v1/users']"
---

# Implement API Endpoint

## Workflow

1. **Locate the API contract.** Find the endpoint specification in the Wave-Ready Package
   or `docs/api-contracts/openapi.yaml`.

2. **Run the Clarifying Questions Gate** if any contract detail is ambiguous (request
   schema, response schema, error codes, auth requirements).

3. **Implement in order:**
   a. Zod validation schema for request input
   b. Service layer function with business logic
   c. Hono route handler (thin: validate, call service, return response)
   d. Error handling for all documented error codes (400, 401, 404, 422, 500)
   e. Authentication/authorization middleware if required

4. **Update the OpenAPI spec** at `docs/api-contracts/openapi.yaml` to match the
   implementation exactly.

5. **Write tests:**
   - Unit tests for the service layer function (Vitest)
   - Integration tests for the endpoint (Vitest + Supertest)
   - Cover: happy path, all error codes, edge cases, auth scenarios

6. **Output the Endpoint Report:**
   ```
   ## Endpoint Complete: [METHOD] [PATH]

   Files created/modified:
   - src/routes/[resource].ts — Route handler
   - src/services/[resource]-service.ts — Business logic
   - src/validators/[resource].ts — Zod schemas
   - src/__tests__/[resource].test.ts — [N] tests
   - docs/api-contracts/openapi.yaml — Updated

   Error codes implemented: 400, 401, 404, 422, 500
   Auth: [JWT required / public]
   Tests: [N] passing
   Manual tasks logged: [any external config needed, or "None"]
   ```

## Quality Criteria
- Response schema must match the API contract exactly (field names, types, nesting)
- All error codes documented in the contract must be implemented
- No raw database errors exposed to clients
- Zod validation on every request input (no unvalidated fields)
```

---

### SKILL 9: .claude/skills/memory/SKILL.md

```markdown
---
name: memory
description: >
  Draft an update to CLAUDE.md or a .claude/rules/ file to capture a learning, pattern,
  or anti-pattern from the current Wave. Use at the end of every Wave (Phase 6) or
  whenever a reusable insight is discovered.
user-invocable: true
argument-hint: "[learning or pattern description]"
---

# Memory Update

## Workflow

1. **Classify the learning:**
   - **Pattern** — a reusable approach that worked well
   - **Anti-pattern** — something that caused issues and should be avoided
   - **Convention update** — a new naming, structure, or process rule
   - **Bug pattern** — a defect class to watch for in future Waves

2. **Determine the target file:**
   - Project-wide learning → `CLAUDE.md` (root)
   - Domain-specific → `.claude/rules/[domain].md`
   - Role-specific → `[directory]/CLAUDE.md`

3. **Draft the update** in the appropriate format:

   For CLAUDE.md (append to learnings section):
   ```
   - YYYY-MM-DD: [concise learning, 1-2 lines max]
   ```

   For rules files (add to appropriate section):
   ```
   ## [Section]
   - [New convention or pattern with brief rationale]
   ```

4. **Verify CLAUDE.md stays under ~100 lines** after the update. If it would exceed
   the limit, identify an older entry to archive or move to a rules file.

5. **Output the proposed update** for the orchestrator's approval before applying:
   ```
   ## Memory Update Proposal

   Target: [file path]
   Type: [Pattern / Anti-pattern / Convention / Bug pattern]

   Addition:
   [exact text to add]

   Location: [after line N / in section X]
   CLAUDE.md line count after update: [N] / 100 max
   ```

## Quality Criteria
- Learnings must be concise (1-2 lines for CLAUDE.md, brief for rules)
- Never exceed ~100 lines in CLAUDE.md
- Do not duplicate information already present in the target file
- Apply the update only after orchestrator approval
```

---

### SKILL 10: .claude/skills/parallel/SKILL.md

```markdown
---
name: parallel
description: >
  Coordinate parallel execution across multiple subagents for a Wave that spans frontend,
  backend, and database work. Splits the Wave-Ready Package into agent-scoped tasks,
  delegates to subagents, and coordinates integration. Use for Waves with cross-cutting
  requirements.
user-invocable: true
argument-hint: "[Wave name or WRP reference]"
---

# Parallel Execution

## Workflow

1. **Read the Wave-Ready Package** and identify components that can be developed
   in parallel (frontend, backend, database).

2. **Initialize the Manual Tasks Tracker.** If `MANUAL_TASKS.md` does not exist, create
   it with the standard template. Each subagent will append manual tasks independently.

3. **Decompose into agent-scoped task briefs:**
   ```
   ## Parallel Task Decomposition: [Wave Name]

   ### Frontend Agent Task
   Scope: [specific UI components, screens, state]
   Acceptance Criteria: [subset from WRP relevant to frontend]
   Dependencies: [API contracts it needs from backend]

   ### Backend Agent Task
   Scope: [specific endpoints, services, validation]
   Acceptance Criteria: [subset from WRP relevant to backend]
   Dependencies: [schemas it needs from database]

   ### Database Agent Task
   Scope: [specific tables, migrations, seeds]
   Acceptance Criteria: [subset from WRP relevant to database]
   Dependencies: [none / shared schema requirements]
   ```

4. **Include Manual Tasks instruction in each brief.** Remind each subagent:
   "Log any tasks requiring manual human action to `MANUAL_TASKS.md` immediately.
   See `.claude/rules/manual-tasks.md` for format."

5. **Identify the execution order:**
   - Database schema changes first (other agents depend on this)
   - Backend and frontend can run in parallel after database is ready
   - Integration testing after all agents complete

6. **Delegate each task brief** to the appropriate subagent.

7. **After all subagents complete:**
   - Run integration tests across the combined output using the test-agent
   - Aggregate manual tasks from all subagents by reading MANUAL_TASKS.md
   - Deduplicate any entries that multiple agents may have logged

8. **Output the Parallel Execution Report:**
   ```
   ## Parallel Execution Report: [Wave Name]

   | Agent | Status | Files Created | Tests |
   |-------|--------|--------------|-------|
   | Database | Complete | [N] files | [N] tests |
   | Backend | Complete | [N] files | [N] tests |
   | Frontend | Complete | [N] files | [N] tests |

   Integration tests: [N] passing / [N] total
   Merge conflicts: [none / list]

   Manual Tasks Summary:
   - New tasks logged during this Wave: [N]
   - Blocking (must complete before deploy): [list or "none"]
   - Non-blocking (can complete after deploy): [list or "none"]

   Ready for Quality Gate: [YES / NO, reason]
   ```

## Quality Criteria
- Each agent task must have a clear, non-overlapping scope
- Shared interfaces (API contracts, schemas) must be defined before parallel execution
- No agent should modify files outside its designated directories
- Integration tests are mandatory after parallel execution
- All manual tasks from all subagents must be aggregated and reported
```

---

### SKILL 11: .claude/skills/testcases/SKILL.md

```markdown
---
name: testcases
description: >
  Generate a structured test plan from a Wave-Ready Package, derive a Test Execution
  Checklist, and generate tests step by step with completion reports. This is the QO's
  primary test generation workflow, analogous to the AO's /implement skill.
user-invocable: true
argument-hint: "[feature name or WRP reference]"
---

# Generate Test Cases from WRP

## Workflow

1. **Read the Wave-Ready Package.** Extract all acceptance criteria, edge cases, error
   states, and boundary conditions.

2. **Run the Clarifying Questions Gate (CQG).** Before generating any tests:
   - Identify ambiguities in acceptance criteria that affect test design
   - Output numbered questions with lettered options
   - Wait for QO sign-off before proceeding

3. **Derive the Test Execution Checklist (TEC):**
   ```
   ## Test Execution Checklist
   [ ] 1. [Test group, e.g., "Unit tests for UserService.createUser()"]
   [ ] 2. [Test group, e.g., "Integration tests for POST /api/v1/users"]
   [ ] 3. [Test group, e.g., "Edge cases: duplicate email, empty fields, max length"]
   [ ] 4. [Test group, e.g., "Auth scenarios: expired token, missing token, wrong role"]
   ...
   ```

4. **Generate tests one TEC item at a time.** After completing each:
   - Mark it complete: [x]
   - Output a Test Step Completion Report
   - **Wait for QO to say "continue" before proceeding**

5. **After all items complete**, output a coverage summary.

## Test Step Completion Report Format

```
## Test Step [N] Complete: [Name]

Files created:
- [path/to/file.test.ts] — [N] tests

Spec coverage:
- [AC-1]: [test name that covers it] ✓
- [AC-2]: [test name that covers it] ✓

Coverage estimate: [X]% contribution

Risks/Flags: [spec ambiguities, missing implementation, manual testing needed]

Updated TEC:
[x] 1. [Done]
[ ] 2. [Next]
[ ] 3. [Pending]

Awaiting confirmation to proceed to Step [N+1].
```

## Quality Criteria
- Test from the spec, not from the implementation (tests validate behavior against spec)
- Every acceptance criterion must have at least one corresponding test
- Include negative tests for every happy path
- No test generation before CQG sign-off
- No batching TEC items without explicit QO instruction
```

---

### SKILL 12: .claude/skills/automate/SKILL.md

```markdown
---
name: automate
description: >
  Generate executable test automation scripts for a feature or user flow. Produces
  ready-to-run test files, not documentation. Use when the QO needs automated test
  scripts for regression, smoke, or E2E testing.
user-invocable: true
argument-hint: "[feature name or user flow]"
---

# Generate Test Automation

## Workflow

1. **Identify the test scope** and determine the appropriate automation framework:
   - API tests: Vitest + Supertest
   - UI unit/widget tests: Flutter Test or React Testing Library
   - E2E flows: Maestro (mobile) or Playwright (web)

2. **Read the acceptance criteria and user flow** from the Wave-Ready Package.

3. **Generate executable test scripts:**
   - Scripts must run without modification (`[TEST_RUNNER]` should pass)
   - Include all imports, setup, teardown, and fixture definitions
   - Use the project's existing test utilities and fixtures

4. **Run the generated tests** and verify they pass against the current implementation.

5. **Output the Automation Report:**
   ```
   ## Test Automation Report: [feature]

   Framework: [Vitest / Maestro / Playwright]

   Files created:
   - [path/to/file.test.ts] — [N] automated tests

   Execution results:
   - Passed: [N]
   - Failed: [N] (with failure details)

   CI integration: [ready / needs pipeline update]
   ```

## Quality Criteria
- Scripts must be immediately executable, not pseudocode
- All external dependencies must be mocked
- E2E scripts must handle setup and teardown (no lingering test data)
- Scripts must run within the pipeline time budget
```

---

### SKILL 13: .claude/skills/coverage/SKILL.md

```markdown
---
name: coverage
description: >
  Analyze test coverage for a module or the entire project. Identify gaps, suggest
  specific tests to write, and prioritize by risk. Use when coverage is below threshold
  or before a Quality Gate review.
user-invocable: true
argument-hint: "[module path or 'all']"
---

# Coverage Gap Analysis

## Workflow

1. **Run the coverage tool** against the specified scope:
   - Backend: `[TEST_RUNNER] --coverage`
   - Frontend: `flutter test --coverage`

2. **Parse the coverage report** and identify:
   - Files below 80% line coverage
   - Uncovered branches and error paths
   - Critical paths with zero coverage (auth, payments, data mutations)

3. **Prioritize gaps by risk:**
   - P1 (Critical): Auth flows, payment processing, data mutations with no tests
   - P2 (High): Public API endpoints, business logic functions
   - P3 (Medium): UI components, utility functions
   - P4 (Low): Configuration, constants, type definitions

4. **Output the Coverage Report:**
   ```
   ## Coverage Analysis: [scope]

   ### Overall: [X]% (target: >80%)

   ### Files Below Threshold
   | File | Coverage | Gap | Priority |
   |------|----------|-----|----------|
   | [path] | [X]% | [what's uncovered] | P1 |

   ### Suggested Tests (ordered by priority)
   1. [P1] [file:function] — test [scenario] to cover [uncovered path]
   2. [P2] [file:function] — test [scenario] to cover [uncovered branch]
   ...

   ### Estimated coverage after suggested tests: [X]%
   ```

## Quality Criteria
- Coverage numbers must come from actual tool output, not estimates
- Suggested tests must be specific enough to implement directly
- Critical paths (P1) must always be flagged regardless of overall coverage percentage
```

---

### SKILL 14: .claude/skills/decision/SKILL.md

```markdown
---
name: decision
description: >
  Structure a Quality Gate approve/reject decision with evidence for each criterion.
  Use when the QO needs to make and document a formal Quality Gate decision for a
  completed Wave.
user-invocable: true
argument-hint: "[Wave name or summary]"
---

# Quality Gate Decision

## Workflow

1. **Gather evidence for each mandatory criterion:**
   - Run all tests and capture results
   - Run coverage report and capture percentage
   - Run linter and capture output
   - Run security scan if available
   - Verify acceptance criteria mapping (use `/validate` output if available)
   - Verify pre-commit hooks pass
   - Check MANUAL_TASKS.md for pending items relevant to this Wave

2. **Evaluate against the decision matrix:**
   - **APPROVE**: All tests pass, coverage >80%, no security issues, all acceptance
     criteria met, API contracts match spec, hooks pass, all manual tasks logged
   - **REQUEST REVISION**: Minor test failures (<3 non-critical), coverage 70-80%,
     low-severity security issues, 1-2 minor criteria gaps
   - **REJECT**: Critical test failures, coverage <70%, high/critical security issues,
     multiple criteria not met, wrong endpoints or schemas

3. **Output the Quality Gate Decision:**
   ```
   ## Quality Gate Decision: [Wave Name]

   ### Decision: APPROVE / REQUEST REVISION / REJECT

   ### Evidence

   | Criterion | Threshold | Actual | Status |
   |-----------|-----------|--------|--------|
   | Unit tests pass | 100% | [X]% | PASS/FAIL |
   | Integration tests pass | 100% | [X]% | PASS/FAIL |
   | Code coverage (new) | >80% | [X]% | PASS/FAIL |
   | Security vulnerabilities | 0 critical/high | [N] found | PASS/FAIL |
   | Linting | 0 errors | [N] errors | PASS/FAIL |
   | Acceptance criteria | 100% | [N]/[Total] | PASS/FAIL |
   | API contract match | Exact | [match/mismatch] | PASS/FAIL |
   | Pre-commit hooks | All pass | [pass/fail] | PASS/FAIL |
   | Manual tasks logged | All tracked | [Y/N] | PASS/FAIL |

   ### AI-Specific Checks
   - Hallucinated functionality: [none found / details]
   - TODO/placeholder comments: [none / count and locations]
   - Fabricated dependencies: [none / details]

   ### Manual Tasks Status
   - Pending for this Wave: [N] ([list brief descriptions])
   - Blocking deployment: [list or "none"]

   ### Required Revisions (if REQUEST REVISION)
   1. [Specific fix with file and line reference]
   2. [Specific fix with file and line reference]

   ### Sign-off
   Decision by: Quality Orchestrator
   Date: [YYYY-MM-DD]
   Wave: [Wave reference]
   ```

## Quality Criteria
- Every criterion must have concrete evidence (actual numbers, not "looks good")
- REQUEST REVISION must include specific, actionable revision items
- REJECT must include clear rationale for each failing criterion
- Decision must be documented, not just communicated verbally
- Manual tasks must be reviewed as part of the gate decision
```

---

### SKILL 15: .claude/skills/pipeline/SKILL.md

```markdown
---
name: pipeline
description: >
  Generate a CI/CD pipeline configuration meeting the OrchState <15 minute SLA from
  merge to production. Use when setting up a new project pipeline or adding stages
  to an existing one.
user-invocable: true
argument-hint: "[project name or feature requiring pipeline changes]"
---

# Generate CI/CD Pipeline

## Workflow

1. **Run the Clarifying Questions Gate:**
   - What triggers the pipeline? (push to main, PR, tag)
   - Which environments? (dev, staging, production)
   - What stages are needed? (build, test, scan, deploy)
   - Any existing pipeline to extend?

2. **Derive the Infrastructure Execution Checklist (IEC):**
   ```
   ## Infrastructure Execution Checklist
   [ ] 1. [Stage, e.g., "Build stage with Docker multi-stage build"]
   [ ] 2. [Stage, e.g., "Unit test stage with coverage reporting"]
   [ ] 3. [Stage, e.g., "Integration test stage with test database"]
   [ ] 4. [Stage, e.g., "Security scan stage"]
   [ ] 5. [Stage, e.g., "Deploy to staging with health check"]
   [ ] 6. [Stage, e.g., "Deploy to production with rollback"]
   ```

3. **Implement one stage at a time.** Each stage must:
   - Have a timeout limit
   - Produce actionable error messages on failure
   - Stay within its time budget allocation

4. **Verify the total pipeline time budget:**
   - Build: <3 min
   - Unit tests: <3 min
   - Integration tests: <5 min
   - Security scan: <2 min
   - Deploy: <2 min
   - **Total: <15 minutes**

5. **Output the Pipeline Report:**
   ```
   ## Pipeline Report: [project]

   File: .github/workflows/[name].yml

   Stages:
   | Stage | Time Budget | Timeout | Trigger |
   |-------|-------------|---------|---------|
   | Build | <3 min | 5 min | [trigger] |
   ...

   Total estimated time: [N] min (budget: <15 min)

   Secrets required: [list of GitHub Secrets needed]
   Manual tasks logged: [any console/dashboard setup needed, or "None"]
   ```

## Quality Criteria
- Total pipeline must complete in <15 minutes
- Every stage must have a timeout
- No secrets hardcoded (use GitHub Secrets or KMS)
- Failed stages must produce actionable error messages
- Deployment stages must include rollback on health check failure
```

---

### SKILL 16: .claude/skills/provision/SKILL.md

```markdown
---
name: provision
description: >
  Generate a Terraform module for provisioning cloud infrastructure. Includes resource
  definition, variables, outputs, and required tags. Use when the PE needs to provision
  new infrastructure resources.
user-invocable: true
argument-hint: "[resource type, e.g., 'PostgreSQL database' or 'Redis cache']"
---

# Provision Infrastructure

## Workflow

1. **Run the Clarifying Questions Gate:**
   - Which environment? (dev, staging, production)
   - Resource specifications (size, capacity, tier)
   - Security requirements (VPC, encryption, access control)
   - Any destructive operations? (flag immediately)

2. **Generate the Terraform module:**
   - Resource definition with all required attributes
   - Variables file with sensible defaults and validation
   - Outputs file for cross-module references
   - Required tags: project, environment, managed_by, owner, cost_center

3. **Include cost estimate** based on the selected resource tier and region.

4. **Generate a dry-run command** the PE can execute before applying.

5. **Output the Provision Report:**
   ```
   ## Provision Report: [resource type]

   Files created:
   - infra/modules/[resource]/main.tf
   - infra/modules/[resource]/variables.tf
   - infra/modules/[resource]/outputs.tf

   Resource: [type and specifications]
   Region: [cloud region]
   Estimated monthly cost: $[amount]

   Dry-run command:
   terraform plan -target=module.[resource]

   Security:
   - Encryption: [at rest / in transit / both]
   - Network: [VPC / public / private subnet]
   - Access: [IAM policy summary]

   Manual tasks logged: [any console setup needed, or "None"]
   ```

## Quality Criteria
- All resources must have required tags
- Remote state with locking (never local state)
- Provider versions pinned (no floating versions)
- Encryption at rest and in transit by default
- No destructive operations without dry-run first
```

---

### SKILL 17: .claude/skills/mcp-config/SKILL.md

```markdown
---
name: mcp-config
description: >
  Generate an MCP server configuration entry with security best practices. Use when
  adding a new MCP server connection for AI agents to interact with databases, cloud
  services, or other tools.
user-invocable: true
argument-hint: "[server name, e.g., 'postgres' or 'github']"
---

# Configure MCP Server

## Workflow

1. **Gather server details:**
   - Server purpose and what agents will use it
   - Authentication method (API key, OAuth, service account)
   - Region and endpoint
   - Which team members/agents need access

2. **Generate the mcp-config.json entry:**
   ```json
   {
     "[server-name]": {
       "command": "[command]",
       "args": ["[args]"],
       "env": {
         "CREDENTIAL_KEY": "REFERENCE_TO_SECRET_MANAGER"
       }
     }
   }
   ```

3. **Verify security requirements:**
   - Credentials reference secret manager or environment variables (never plaintext)
   - Least-privilege access (only the permissions the agents need)
   - Server version pinned (no @latest)

4. **Test connectivity** from worktree directories (subagents run in worktrees and
   must be able to reach MCP servers).

5. **Output the MCP Configuration Report:**
   ```
   ## MCP Server Configured: [server-name]

   File: .mcp/mcp-config.json
   Purpose: [what it does]
   Access: [which agents/roles use it]

   Security:
   - Credentials: [reference to secret store]
   - Permissions: [scope of access]
   - Version: [pinned version]

   Worktree verification: [confirmed accessible from .claude/worktrees/]
   Manual tasks logged: [credential/console setup needed, or "None"]
   ```

## Quality Criteria
- Never include plaintext credentials
- Always pin server/package versions
- Verify worktree accessibility
- Document which agents depend on this server
```

---

### SKILL 18: .claude/skills/monitor/SKILL.md

```markdown
---
name: monitor
description: >
  Generate monitoring and alerting configuration for a service. Includes metrics
  collection, alert thresholds, and dashboard definition. Use when setting up
  observability for a new or existing service.
user-invocable: true
argument-hint: "[service name]"
---

# Configure Monitoring

## Workflow

1. **Identify the monitoring scope:**
   - Service type (API, worker, database, cache)
   - Key business metrics (response time, error rate, throughput)
   - Infrastructure metrics (CPU, memory, disk, network)

2. **Define alert thresholds:**
   | Metric | Warning | Critical | Action |
   |--------|---------|----------|--------|
   | Response time (p95) | >500ms | >2s | Scale / investigate |
   | Error rate (5xx) | >1% | >5% | Page on-call |
   | CPU usage | >70% | >90% | Auto-scale |
   | Memory usage | >80% | >95% | Investigate leak |
   | Disk usage | >75% | >90% | Expand / clean |

3. **Generate configuration files** for the project's monitoring stack.

4. **Output the Monitoring Report:**
   ```
   ## Monitoring Report: [service]

   Files created:
   - infra/monitoring/[service]-alerts.yaml
   - infra/monitoring/[service]-dashboard.json

   Metrics tracked: [count]
   Alerts configured: [count] ([N] warning, [N] critical)
   Dashboard panels: [count]

   On-call escalation: [configured / needs manual setup]
   Manual tasks logged: [dashboard/console setup needed, or "None"]
   ```

## Quality Criteria
- Every service must have at least: response time, error rate, and resource utilization alerts
- Critical alerts must have an escalation path defined
- Dashboard must show both real-time and historical views
- Alert thresholds must be documented with rationale
```

---

### SKILL 19: .claude/skills/rollback/SKILL.md

```markdown
---
name: rollback
description: >
  Generate a rollback procedure for a service deployment. Includes rollback steps,
  verification checks, and communication template. Use when preparing deployment
  safety nets or responding to a failed deployment.
user-invocable: true
argument-hint: "[service name or deployment reference]"
---

# Generate Rollback Procedure

## Workflow

1. **Identify rollback scope:**
   - Which service(s) are affected
   - What changed in this deployment (code, schema, infrastructure)
   - Are there database migrations that need reversal?

2. **Generate the rollback procedure:**
   ```
   ## Rollback Procedure: [service] — [deployment reference]

   ### Pre-Rollback Checks
   - [ ] Confirm the issue is deployment-related (not external dependency)
   - [ ] Identify the last known good version: [version/commit]
   - [ ] Check if database migrations are reversible

   ### Rollback Steps
   1. [Step with exact command]
   2. [Step with exact command]
   3. [Verification check after each step]

   ### Post-Rollback Verification
   - [ ] Health check endpoint returns 200
   - [ ] Key user flows functional (list specific flows)
   - [ ] Error rate returned to baseline
   - [ ] No data loss or corruption

   ### Communication
   - Notify: [stakeholders]
   - Status page: [update text]
   - Post-mortem: [scheduled within 24 hours]
   ```

3. **Flag irreversible changes** (destructive migrations, data deletions) that cannot
   be rolled back automatically.

## Quality Criteria
- Every rollback step must have a verification check
- Irreversible changes must be prominently flagged
- Rollback must be executable without human judgment calls (pre-decided steps)
- Communication template must be included
```

---

### SKILL 20: .claude/skills/incident/SKILL.md

```markdown
---
name: incident
description: >
  Start an incident response workflow. Guides through diagnosis, mitigation, resolution,
  and post-mortem documentation. Use when a production issue is reported.
user-invocable: true
argument-hint: "[symptom description]"
---

# Incident Response

## Workflow

1. **Capture incident details:**
   ```
   ## Incident Report

   Reported: [timestamp]
   Symptom: [what is happening]
   Impact: [users/services affected]
   Severity: [P1 Critical / P2 High / P3 Medium / P4 Low]
   ```

2. **Diagnose:**
   - Check application logs for errors
   - Check monitoring dashboards for anomalies
   - Check recent deployments (was anything deployed in the last hour?)
   - Check external dependencies (are third-party services healthy?)
   - Check infrastructure (CPU, memory, disk, network)

3. **Mitigate** (stop the bleeding before finding root cause):
   - If deployment-related: rollback using `/rollback`
   - If traffic-related: scale or enable rate limiting
   - If dependency-related: enable circuit breaker or fallback

4. **Resolve** (fix the root cause):
   - Identify root cause from diagnosis
   - Implement fix using `/fix`
   - Deploy fix through normal pipeline

5. **Document the incident:**
   ```
   ## Incident Post-Mortem

   Incident: [title]
   Duration: [start] to [resolution]
   Impact: [quantified: users affected, revenue impact, SLA breach]

   ### Timeline
   | Time | Event |
   |------|-------|
   | [time] | [what happened] |

   ### Root Cause
   [detailed explanation]

   ### Resolution
   [what was done to fix it]

   ### Action Items
   | # | Action | Owner | Due Date |
   |---|--------|-------|----------|
   | 1 | [preventive measure] | [name] | [date] |

   ### Lessons Learned
   [what to do differently next time]
   ```

6. **Update CLAUDE.md** with the incident pattern using `/memory`.

## Quality Criteria
- Mitigation must happen before root cause analysis (stop the bleeding first)
- Timeline must capture all key events with timestamps
- Action items must have owners and due dates
- Post-mortem must be blameless (focus on systems, not people)
```

---

### Adapting Skills for Custom Stacks

When the user selects a custom stack, adapt the skill templates as follows:

1. **Replace tool/command placeholders** with the actual project tools:
   - `[TEST_RUNNER]` → `bun test`, `npm test`, `pytest`, etc.
   - `[LINTER]` → `npx biome check`, `eslint`, `ruff`, etc.
   - `[FORMATTER]` → `npx biome format`, `prettier`, `black`, etc.

2. **Replace framework-specific references** in workflow steps:
   - Zod → Yup, Joi, Pydantic, etc.
   - Hono → Express, FastAPI, Django, etc.
   - Drizzle → Prisma, SQLAlchemy, TypeORM, etc.
   - Vitest → Jest, pytest, etc.
   - Flutter Test → React Testing Library, etc.

3. **Preserve all OrchState methodology constructs:**
   - Clarifying Questions Gate (CQG)
   - Wave Execution Checklist (WEC) / Test Execution Checklist (TEC)
   - Step Completion Reports (including Manual Tasks field)
   - Wave Completion Summary (AO→QO handoff artifact)
   - Quality Gate criteria and decision matrix (including manual tasks check)
   - Memory update protocol
   - Manual Tasks Tracker convention
   - .env.example sync convention

4. **Do not change the workflow structure** (step order, output format, quality criteria).
   The methodology is stack-agnostic; only the tool names change.

---

## README.md

```markdown
# [Project Name]

[Project description from intake — 2-3 sentences]

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | [Framework + state management] |
| Backend | [Runtime + framework] |
| Database | [Database + ORM] |
| Auth | [Auth method] |
| Cloud | [Provider + region] |
| CI/CD | [Platform] |

## Project Structure

```
[Include the full directory tree from SKILL.md with actual feature names]
```

## Getting Started with Claude Code

1. Clone this repository
2. Open the project root in your terminal
3. Run `claude` to start Claude Code — it will read the `CLAUDE.md` file automatically
4. Subagents are pre-configured in `.claude/agents/` and activate automatically when Claude identifies a matching task
5. Every subagent runs in its own git worktree for isolation — no manual setup needed
6. Review the Wave-Ready Packages in `docs/wave-packages/` to understand what to build
7. Start executing Waves using the Phase 1-6 lifecycle described in `CLAUDE.md`
8. Check `MANUAL_TASKS.md` for any pending tasks that require manual action (the session-start hook will remind you automatically)

### Subagent Configuration

This project includes pre-configured subagents in `.claude/agents/`:

| Subagent | File | Scope | Isolation |
|----------|------|-------|-----------|
| Frontend Agent | `.claude/agents/frontend-agent.md` | UI, screens, state management | Worktree |
| Backend Agent | `.claude/agents/backend-agent.md` | API endpoints, business logic | Worktree |
| Database Agent | `.claude/agents/database-agent.md` | Schema, migrations, queries | Worktree |
| Test Agent | `.claude/agents/test-agent.md` | Test suites, coverage analysis | Worktree |
| Infra Agent | `.claude/agents/infra-agent.md` | Pipelines, IaC, monitoring | Worktree |

Claude Code automatically delegates tasks to the appropriate subagent based on the task description. You can also invoke them explicitly:
- "Use the backend-agent to implement the user registration endpoint"
- "Have the test-agent generate tests for the auth flow"

Each subagent runs in an isolated git worktree, so multiple agents can work in parallel without file conflicts.

### Skills (On-Demand Workflows)

Type `/` in Claude Code to see all available skills. Key workflows:

| Skill | Role | Purpose |
|-------|------|---------|
| `/implement [feature]` | AO | Full Wave execution with CQG + WEC |
| `/gate` | All | Quality Gate self-assessment |
| `/testcases [feature]` | QO | Test plan with TEC + step-by-step generation |
| `/pipeline [project]` | PE | CI/CD pipeline generation |
| `/fix [bug]` | AO | Bug fix + regression test |
| `/decision [wave]` | QO | Formal QG approve/reject |

### Agent Context Files

Each subdirectory also has a `CLAUDE.md` that provides role-specific conventions:

| Directory | Agent Role | What It Does |
|-----------|-----------|-------------|
| `mobile/` or `frontend/` | Frontend Agent | UI components, screens, state management |
| `backend/` | Backend Agent | API endpoints, business logic, validation |
| `database/` | Database Agent | Schema design, migrations, queries |
| `tests/` | Test Agent | Unit tests, integration tests, E2E scaffolds |
| `infra/` | Infrastructure Agent | Pipelines, IaC, monitoring |

### Wave-Ready Packages

All feature specifications are in [`docs/wave-packages/`](docs/wave-packages/). Each file contains the complete requirements for one Wave: intent, user stories, API contracts, content spec, and edge cases.

### API Contracts

OpenAPI specification is at [`docs/api-contracts/openapi.yaml`](docs/api-contracts/openapi.yaml).
```

---

## MANUAL_TASKS.md

The Manual Tasks Tracker file lives at the project root and is version controlled. Generate
it with this initial template:

```markdown
# Manual Tasks Tracker
> Auto-maintained by Claude Code. Developers: check off items as you complete them.
> The session-start hook will remind you of pending tasks at every session.

## Pending

(No pending tasks yet. Claude Code agents will append tasks here when they encounter
actions requiring manual human intervention during Wave execution.)

## Completed

(Move completed items here with a date and any relevant details.)
```

---

## .env.example

Generate based on the stack. Here are common patterns:

### For Bun/Hono + PostgreSQL (Organization Default Stack)
```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/[project_name]_dev

# Auth
JWT_SECRET=your-jwt-secret-here
JWT_EXPIRES_IN=7d
NAFATH_CALLBACK_URL=https://api.[domain]/auth/nafath/callback

# Cloud (Alibaba Cloud KSA)
ALIBABA_ACCESS_KEY_ID=your-access-key
ALIBABA_ACCESS_KEY_SECRET=your-secret-key
ALIBABA_REGION=me-east-1
OSS_BUCKET=[project_name]-assets

# Application
PORT=3000
NODE_ENV=development
API_BASE_URL=http://localhost:3000

# Feature Flags
FEATURE_ARABIC_SUPPORT=true
```

### For Next.js + Supabase (Example Custom Stack)
```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-key

# Application
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Adapt the template to the actual stack selected. Always include:
- Database connection (even if placeholder)
- Auth credentials (placeholder)
- Cloud/deployment references (placeholder)
- Application config (port, base URL, environment)

**Note:** The `.claude/rules/manual-tasks.md` convention instructs agents to update this
file whenever they introduce a new environment variable in code. If the variable's value
requires manual acquisition (e.g., API key from a dashboard), agents will also log it to
`MANUAL_TASKS.md`.

---

## docs/wave-packages/README.md

```markdown
# Wave-Ready Packages

This directory contains all Wave-Ready Packages for the project. Each file specifies everything an Agent Orchestrator needs to execute one Wave.

## Package Index

| # | Feature | Status | Owner | Date |
|---|---------|--------|-------|------|
| 001 | [Feature name] | [Ready / In Progress / Pending] | [Name] | [Date] |
| 002 | [Feature name] | [Ready / In Progress / Pending] | [Name] | [Date] |

## How to Use

1. Pick the next `Ready` Wave from the table above
2. Open the corresponding `wave-NNN-[feature].md` file
3. Read the Intent Definition to understand the problem
4. Use the acceptance criteria, API contracts, and content spec to brief your agents
5. Execute the Wave following the Phase 1-6 lifecycle in the root `CLAUDE.md`
6. Subagents in `.claude/agents/` will activate automatically when you delegate tasks
7. After completing the Wave, update the Status column to `Complete`

## Creating New Wave Packages

Use Claude with the `orchstate-wave-ready-package` skill:
> "Create a Wave-Ready Package for [feature description]"

Save the output as `wave-NNN-[feature-slug].md` in this directory and update the index table above.
```

---

## docs/architecture/decisions.md

```markdown
# Architecture Decision Records

Record important technical decisions here so the team (and AI agents) understand why things are the way they are.

## Template

### ADR-NNN: [Decision Title]
**Date:** YYYY-MM-DD
**Status:** [Proposed / Accepted / Deprecated / Superseded]
**Context:** What is the issue we are deciding on?
**Decision:** What did we decide?
**Consequences:** What are the trade-offs? What becomes easier or harder?

---

## Decisions

(No decisions recorded yet. Add them as the project evolves.)
```

---

## docs/agent-prompts/README.md

```markdown
# Agent Prompt Templates

Reusable prompt templates that any Agent Orchestrator can use for consistent results. These supplement the CLAUDE.md files and `.claude/agents/` subagent definitions with task-specific prompts.

## Feature Implementation
```
Implement [FEATURE_NAME] based on the following specification:
Intent: [PROBLEM_STATEMENT]
User Stories: [LIST_STORIES]
Acceptance Criteria: [LIST_CRITERIA]
API Contract: [ENDPOINTS]
Follow the patterns in CLAUDE.md. Generate complete, tested code.
```

## Bug Fix
```
Fix the following bug:
Symptom: [DESCRIPTION]
Steps to reproduce: [STEPS]
Expected behavior: [EXPECTED]
Actual behavior: [ACTUAL]
Analyze the root cause, implement fix, and add regression test.
```

## Test Generation
```
Generate comprehensive tests for [FILE/FUNCTION]:
Cover: unit tests, edge cases, error handling, boundary conditions.
Framework: [TEST_FRAMEWORK from CLAUDE.md]
Target coverage: >80%
```

## Quality Gate Review
```
Review this code for Quality Gate:
[CODE_OR_DESCRIPTION]
Check against: unit test coverage, security vulnerabilities,
acceptance criteria, code standards.
Report pass/fail with findings.
```

## Parallel Wave Execution
```
Execute the following Wave tasks in parallel using subagents:
- Frontend: [TASK_DESCRIPTION] (use frontend-agent)
- Backend: [TASK_DESCRIPTION] (use backend-agent)
- Database: [TASK_DESCRIPTION] (use database-agent)
After all agents complete, run integration tests using test-agent.
```
```

---

## docs/api-contracts/openapi.yaml

### Stub (when no WRPs with API contracts are provided)
```yaml
openapi: 3.0.3
info:
  title: [Project Name] API
  description: API specification for [Project Name]. Populate endpoints as Wave-Ready Packages are created.
  version: 0.1.0
servers:
  - url: http://localhost:3000/api/v1
    description: Local development
paths: {}
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
```

### Populated (when WRPs contain API contracts)
Extract all endpoints from the provided WRPs and merge them into a single OpenAPI file. For each endpoint:
- Map the HTTP method and path
- Convert the request/response schemas from WRP table format to OpenAPI schema objects
- Include error responses (400, 401, 404, 422, 500)
- Add authentication requirements
- Add pagination parameters for list endpoints

---

## .mcp/mcp-config.json

### Template (no MCP servers specified)
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "mcpServers": {}
}
```

### Populated (with MCP servers)
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "mcpServers": {
    "[server-name]": {
      "command": "[command]",
      "args": ["[args]"],
      "env": {
        "CREDENTIAL_KEY": "REFERENCE_TO_SECRET_MANAGER"
      }
    }
  }
}
```

For the organization default stack, pre-populate:
```json
{
  "mcpServers": {
    "postgres-mcp": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-postgres"],
      "env": {
        "DATABASE_URL": "REFERENCE_TO_SECRET_MANAGER"
      }
    }
  }
}
```

Never include real credentials. Always use references to secret managers or environment variables.

---

## Wave Package File Naming

When creating wave package files from provided WRPs:

1. Extract the feature name from the WRP header
2. Convert to kebab-case: "Driver Location Sharing" → "driver-location-sharing"
3. Assign the next available sequence number
4. Filename: `wave-001-driver-location-sharing.md`

When creating placeholder files:
- Use `wave-001-placeholder.md` with the pending template from SKILL.md
- The user replaces these with real WRPs later

---

## File Generation Order

Generate files in this order to avoid forward references:

1. Directory structure (mkdir -p all paths, including `.claude/agents/`, `.claude/hooks/`, `.claude/rules/`, `.claude/skills/[name]/` for each of the 20 skill directories)
2. `.claude/settings.json` (permissions, defaults, hook configuration with correct nested format)
3. `.claude/agents/*.md` (subagent definitions, one per role, with Manual Tasks instruction)
4. `.claude/hooks/*.sh` (all four hook scripts, mark executable with chmod +x)
5. `.claude/rules/*.md` (domain-specific convention files plus `manual-tasks.md`)
6. `.claude/skills/*/SKILL.md` (all 20 on-demand workflow definitions with full content)
7. `MANUAL_TASKS.md` (empty tracker template at project root)
8. `.env.example` (referenced by CLAUDE.md files)
9. Master `CLAUDE.md` (references directories, agents, manual tasks, and file paths)
10. Agent-specific `CLAUDE.md` files (reference master for shared context)
11. Wave package files in `docs/wave-packages/`
12. Wave packages `README.md` (indexes the wave files)
13. `docs/api-contracts/openapi.yaml` (extracted from wave packages)
14. `docs/architecture/decisions.md`
15. `docs/agent-prompts/README.md`
16. `.mcp/mcp-config.json`
17. `README.md` (references everything above including full `.claude/` structure)
18. `.gitignore` (includes CLAUDE.local.md, settings.local.json, .claude/worktrees/)
19. `.gitkeep` files in empty directories
20. Zip and present
